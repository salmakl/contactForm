<?php


/**
 * Plugin name: Contact form
 * Description: Simple non-bloated WordPress Contact Form
 * 
 */


register_activation_hook(__FILE__,'tablecreation');

function tablecreation() {

global $wpdb;
$contact_table_name = $wpdb->prefix . 'wp_contact';

$sql = "CREATE TABLE IF NOT EXISTS $contact_table_name (
	id int NOT NULL PRIMARY KEY AUTO_INCREMENT,
	name varchar(45) DEFAULT NULL,
	email varchar(20) DEFAULT NULL,
	subject varchar(20) DEFAULT NULL,
	message text DEFAULT NULL)";

     $wpdb->query($sql);
}

add_action('admin_menu','admin_menu');
register_uninstall_hook(__FILE__,'droptable');


function admin_menu () {
     add_menu_page("contact form","Contact Menu","manage_options","Contact-menu","admin","dashicons-format-status",3);
}

function admin()
{
     include "admincontact.php";
}

function droptable() 
{
     global $wpdb;
     $contact_table_name = $wpdb->prefix . 'wp_contact';

     $wpdb-> query("DROP table $contact_table_name ");
}


 function ContactForm()
 {
      include "form.php";
 }

add_shortcode('Contact','ContactForm');





 ?>