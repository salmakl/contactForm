<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
global $wpdb;


if(isset($_POST['send']))
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $subject=$_POST['subject'];
    $message=$_POST['message'];

    $table_name='wp_contact';

    // $sql="INSERT INTO wp_contact (name,email,subject,message) VALUES ('$name','$email','$subject','$message')";
    $wpdb->insert( $table_name, array('name'=>$name,'email'=>$email,'subject'=>$subject,'message'=>$message), array( '$s', '$s','$s','$s') );

}


?>

<form action="form.php" method="POST">

    <div>
    <label for="name">Name</label>
    <input type="text" name= "name" placeholder="Enter your name" >
    </div>

    <div>
    <label for="email">Email</label>
    <input type="text" name= "email" placeholder="Enter your e-mail" >
    </div>

    <div>
    <label for="subject">Subject</label>
    <input type="subject" name= "name" placeholder="Enter a subject" >
    </div>

    <div>
    <label for="message">Message</label>
    <textarea name="message" id="" cols="30" rows="10" placeholder="Message" ></textarea>
    </div>

    <div>
    <input type="submit" value="Send" name="send">
    </div>

</form>


</body>
</html>