<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Document</title>
</head>
<body>
<!-- TAAABLE -->
<h1>HELLO</h1>
<table class="table-dark">
<tr>
<th>id</th> 
<th>Name</th>
<th>E-mail</th>
<th>Subject</th>
<th>Message</th>
<th>Actions</th>
</tr>


<?php 
$data=getData();
    foreach($data as $row)
    {


        // echo $row->id;
        echo "<tr>";
        echo "<td>".$row->id."</td>";
        echo "<td>".$row->name."</td>";
        echo "<td>".$row->email."</td>";
        echo "<td>".$row->subject."</td>";
        echo "<td>".$row->message."</td>";
        echo "<form  method='POST'>
        <input type='hidden' name='id' value='".$row->id."'>
        <td><input type='submit' name='delete' value='DELETE'></td>  
        </form>";
        echo '<td>
        <form  action="#" method="post">
        <button type="submit" class="btn btn-warning" name="response" onclick = "show_response()" ;> Reply <i class="fas fa-reply"></i> </button>
      </form>&nbsp;
        </td>';
       
        
         
         
    }

    if(isset($_POST['delete'])){
        global $wpdb;
        $id=$_POST['id'];
        $deleted=$wpdb->query("DELETE FROM wp_contact WHERE id =$id");
        
    }


    ?>





</table>
  
</body>
<div id="response" style="display: none;">
  <div class="card" style="width: 35rem; height: 15rem;">
    <div class = "d-flex justify-content-between">
      <h2 class="card-title">Response </h2> 
      <button type="button" class="close" onclick ="hide_response()">
        <span aria-hidden="true">&times;</span>
      </button> 
    </div>

    <div class="card-body d-flex justify-content-center align-items-center">
      <form action="#" method="POST" class="text-center align-items-center">

        <p class="send_msg"> Write your response </p>

        <textarea type= "text" name ="Response" class="textarea" placeholder = "Enter your response"></textarea>
        <button type="button" name="send" class="btn btn-danger" onclick="send()">
          Send
        </button> 

      </form>
    </div>
  </div>
</div>

<script type="text/javascript">

  //response popup
  function show_response() {
    document.getElementById("response").style.display = "block";
  }

  function hide_response() {
    document.getElementById("response").style.display = "none";
  }

  function send() {

  }

  //delete popup
  function show_delete() {
    document.getElementById("delete").style.display = "block";
  }

  function hide_delete() {
    document.getElementById("delete").style.display = "none";
  }

  function Delete() {

  }
</script>

</html>

<?php
 
 function getData()
 {
 
     global $wpdb;
     $data = $wpdb->get_results("SELECT * FROM wp_contact");
     return $data;
 }
//  var_dump(getData());

function Delete($id)
{

}
?>