<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<form method="POST"  action="" >

    <div>
    <label for="name">Name</label>
    <input type="text" name= "cname" placeholder="Enter your name" >
    </div>

    <div>
    <label for="email">Email</label>
    <input type="text" name= "email" placeholder="Enter your e-mail" >
    </div>

    <div>
    <label for="subject">Subject</label>
    <input type="subject" name= "subject" placeholder="Enter a subject" >
    </div>

    <div>
    <label for="message">Message</label>
    <textarea name="message" id="" cols="30" rows="10" placeholder="Message" ></textarea>
    </div>

    <div>
    <input type="submit" value="Send" name="send">
    </div>

</form>


</body>
</html>

<?php




if(isset($_POST['send']))
{
    
    $name=$_POST['cname'];
    $email=$_POST['email'];
    $subject=$_POST['subject'];
    $message=$_POST['message'];

    global $wpdb;
    $table_name = $wpdb->prefix . 'contact';

    $wpdb->insert(
        $table_name,
        [
            'name' => $name,
            'email' => $email,
            'subject' => $subject,
            'message' => $message
        ]
    );

}


?>
