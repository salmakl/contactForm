<?php


/**
 * Plugin name: Contact form
 * Description: Simple non-bloated WordPress Contact Form
 * 
 */
wp_enqueue_style('bootstrap4', 'https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css%27');
wp_enqueue_script('boot1', 'https://code.jquery.com/jquery-3.3.1.slim.min.js%27');
wp_enqueue_script('boot2', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js%27');
wp_enqueue_script('boot2', 'https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js%27');

register_activation_hook(__FILE__,'tablecreation');

function tablecreation() {

global $wpdb;
$contact_table_name = $wpdb->prefix . 'contact';

$sql = "CREATE TABLE IF NOT EXISTS $contact_table_name (
	id int NOT NULL PRIMARY KEY AUTO_INCREMENT,
	name varchar(45) DEFAULT NULL,
	email varchar(20) DEFAULT NULL,
	subject varchar(20) DEFAULT NULL,
	message text DEFAULT NULL)";

     $wpdb->query($sql);
}

add_action('admin_menu','admin_menu');
register_uninstall_hook(__FILE__,'droptable');


function admin_menu () {
     add_menu_page("contact form","Contact Menu","manage_options","Contact-menu","admin","dashicons-format-status",3);
     add_submenu_page("Contact-menu","result","infos","manage_options","infos-contact","Results");
}

function admin()
{
     include "admincontact.php";
}

function droptable() 
{
     global $wpdb;
     $contact_table_name = $wpdb->prefix . 'contact';

     $wpdb-> query("DROP table $contact_table_name ");
}


 function Results()
 {
      include "admincontact.php";
 }

// add_shortcode('Contact','ContactForm');

function cf_shortcode()
{
     include "form.php";

    return ob_get_clean();
}

add_shortcode('Contact', 'cf_shortcode');

 ?>